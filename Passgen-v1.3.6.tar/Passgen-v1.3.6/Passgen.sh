#!/bin/bash

touch genpasswd.txt

openssl rand -base64 17 >> genpasswd.txt
